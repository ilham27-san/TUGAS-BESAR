<?php
// favorite-recipes.php
header('Content-Type: application/json');

try {
    $pdo = new PDO("mysql:host=localhost;dbname=resep_db", 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Ambil resep favorit dari database (is_favorite = 1)
    $stmt = $pdo->prepare("SELECT * FROM recipes WHERE is_favorite = 1");
    $stmt->execute();
    $recipes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Mengembalikan data resep favorit dalam format JSON
    echo json_encode($recipes); 
} catch (PDOException $e) {
    echo json_encode(['error' => 'Terjadi kesalahan: ' . $e->getMessage()]);
}
?>
