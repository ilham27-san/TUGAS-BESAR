<?php
$host = 'localhost'; // Ganti dengan host database Anda
$dbname = 'resep_db'; // Nama database
$username = 'root'; // Ganti dengan username MySQL Anda
$password = ''; // Ganti dengan password MySQL Anda

header('Content-Type: application/json');

try {
    $pdo = new PDO("mysql:host=localhost;dbname=resep_db", 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Cek jika ada parameter pencarian
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $search = '%' . $_GET['search'] . '%'; // Membuat wildcard pencarian
        $stmt = $pdo->prepare("SELECT * FROM recipes WHERE name LIKE ? OR ingredients LIKE ?");
        $stmt->execute([$search, $search]);
        $recipes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        // Ambil semua resep jika tidak ada pencarian
        $stmt = $pdo->query("SELECT * FROM recipes");
        $recipes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Mengembalikan data dalam format JSON
    echo json_encode($recipes);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
