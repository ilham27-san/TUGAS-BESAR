<?php
header('Content-Type: application/json');

// Periksa apakah ID resep diberikan
if (!isset($_GET['id'])) {
    echo json_encode(["error" => "ID resep tidak diberikan"]);
    exit;
}

$id = $_GET['id'];

try {
    // Koneksi ke database
    $pdo = new PDO("mysql:host=localhost;dbname=resep_db", 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Ambil status favorit saat ini
    $stmt = $pdo->prepare("SELECT is_favorite FROM recipes WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $recipe = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$recipe) {
        echo json_encode(["error" => "Resep tidak ditemukan"]);
        exit;
    }

    // Ubah status favorit
    $newStatus = ($recipe['is_favorite'] == 1) ? 0 : 1;

    // Update status favorit di database
    $updateStmt = $pdo->prepare("UPDATE recipes SET is_favorite = :is_favorite WHERE id = :id");
    $updateStmt->execute(['is_favorite' => $newStatus, 'id' => $id]);

    echo json_encode(["success" => "Status favorit berhasil diubah", "is_favorite" => $newStatus]);

} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
