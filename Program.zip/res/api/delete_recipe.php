<?php
header('Content-Type: application/json');

// Sertakan file konfigurasi untuk koneksi database
require_once 'config.php';

// Periksa apakah ID diberikan
if (!isset($_GET['id'])) {
    echo json_encode(["error" => "ID tidak diberikan"]);
    exit;
}

$id = $_GET['id'];
$response = [];

try {
    // Query untuk menghapus resep berdasarkan ID
    $stmt = $pdo->prepare("DELETE FROM recipes WHERE id = :id");
    $stmt->execute(['id' => $id]);

    if ($stmt->rowCount() > 0) {
        // Hapus berhasil
        $response['success'] = "Resep berhasil dihapus";

        // Reset auto-increment ID
        $pdo->exec("SET @count = 0");
        $pdo->exec("UPDATE recipes SET id = (@count := @count + 1)");
        $pdo->exec("ALTER TABLE recipes AUTO_INCREMENT = 1");

        $response['reset'] = "ID berhasil direset";
    } else {
        $response['error'] = "Resep tidak ditemukan atau gagal dihapus";
    }
} catch (PDOException $e) {
    $response['error'] = "Terjadi kesalahan: " . $e->getMessage();
}

// Kembalikan respon sebagai JSON
echo json_encode($response);
?>
