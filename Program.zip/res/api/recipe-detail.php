<?php
header('Content-Type: application/json');

// Sertakan file konfigurasi untuk koneksi database
require_once 'config.php';

// Periksa apakah ID diberikan
if (!isset($_GET['id'])) {
    echo json_encode(["error" => "ID tidak diberikan"]);
    exit;
}

$id = $_GET['id'];

try {
    // Ambil data resep berdasarkan ID
    $stmt = $pdo->prepare("SELECT * FROM recipes WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $recipe = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$recipe) {
        echo json_encode(["error" => "Resep tidak ditemukan"]);
        exit;
    }

    // Kembalikan data resep sebagai JSON
    echo json_encode($recipe);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
