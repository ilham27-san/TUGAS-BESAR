<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $ingredients = $_POST['ingredients'];
    $instructions = $_POST['instructions'];
    $image_url = $_POST['image_url'] ?? null;

    // Masukkan data ke database (proses ini seperti yang sebelumnya)
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=resep_db", 'root', '');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $pdo->prepare("INSERT INTO recipes (name, ingredients, instructions, image_url) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $ingredients, $instructions, $image_url]);

          header("Location: index.html?success=true");
        exit(); // Pastikan kode berikutnya tidak dieksekusi setelah redirect
    } catch (PDOException $e) {
        echo "<p>Terjadi kesalahan: " . $e->getMessage() . "</p>";
    }
}
?>
